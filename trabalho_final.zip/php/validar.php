<?php  
    SESSION_START();
    $login = isset($_POST["login"])? strtolower($_POST["login"]):"";
    $senha = isset($_POST["senha"])? md5($_POST["senha"]):"";
    $perfil = isset($_POST["perfil"])? strtolower($_POST["perfil"]):"";
    include_once '../crud/conexao.php';

    $log = mysqli_query($conn, 
    "SELECT * FROM tbl_usuarios WHERE usuario = '$login' AND senha = '$senha' AND perfil = '$perfil' ") or die(mysqli_error());
   
    
    $linha = mysqli_fetch_array($log);

    if($login == "" || $senha == "")
    {   echo "<script> alert('Preencha os campos!') </script>";}

    if($login != $linha['usuario'] && $senha != $linha['senha'])
    { echo "Acesso Restrito, efetue o login!"; }

    if($login == $linha['usuario'] && $senha == $linha['senha'] && $perfil == "adm"){
        $_SESSION["usuario"] = $linha['nomeusuario'];
        echo"
        <script> 
            window.location.href = '../menu.php';
        </script>";    
    }
    
    if($login == $linha['usuario'] && $senha == $linha['senha'] && $perfil == "user"){
        $_SESSION["usuario"] = $linha['nomeusuario'];
        echo"
        <script> 
            window.location.href = 'menuuser.php';
        </script>";    
    }

    else{ 
        echo"<script>
        alert(' [ERRO] Acesso Restrito!');
        window.location.href = '../index.php';</script>";    
    } 


?>