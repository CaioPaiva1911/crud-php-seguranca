<?php 
    SESSION_START();

    SESSION_DESTROY();

?>

<script>
    window.location.href = "../index.php";
</script>