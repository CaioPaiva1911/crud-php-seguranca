<?php

    $server = "localhost";
    $user = "root";
    $password = "";
    $banco = "bdsapataria";
    
    $conn = mysqli_connect($server, $user, $password, $banco);
    

?>